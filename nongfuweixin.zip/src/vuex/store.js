 import Vue from 'vue';
 import Vuex from 'vuex';

 Vue.use(Vuex);
 const state = {
   marker: {
 
   },
   gysId:null,
   gysDetail:null

 }
 const mutations = {
   // 对marker进行设置,为了传递参数
   updateMarker(state, newMarker) {
     console.log(newMarker);
     state.marker = newMarker;
   },
    // 对marker进行设置,为了传递参数
    updateGysId(state, newGysId) {
      console.log(newGysId);
      state.gysId = newGysId;
    },
    // 对选中的服务类型id进行设置
    updateGysDetail(state, GysDetail) {
      console.log(GysDetail);
      state.gysDetail = GysDetail;
    }
 }
 export default new Vuex.Store({
   state,
   mutations
 })
