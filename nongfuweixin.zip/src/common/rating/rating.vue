<template>
    <div class="rating">
        <li class="item"></li>
    </div>
</template>
<script>
    export default {
        name:"rating",
        props:{
            
        }
    }
</script>
<style lang="scss" scoped>
.rating{

}
</style>

