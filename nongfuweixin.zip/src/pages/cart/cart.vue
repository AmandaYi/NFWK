<template>
    
    <div class="cart-page">
        <order-header :title="title">
          <span>编辑</span>
        </order-header>
       <!-- 主题内容 -->
        <div class="content">
            <li class="order-item">
                    <div class="order-company">
                        <i class="iconfont icon-yuanxuanze"></i>
                        <i class="iconfont icon-jiameng-1"></i>
                        <span class="company-name">北京翼农飞防植保联盟  </span>
                        <i class="iconfont icon-jiantou"></i>
                    </div>
          
                    <ul class="order-detail">
                        <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                            <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                                <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                    </ul>
            </li>
                <li class="order-item">
                    <div class="order-company">
                        <i class="iconfont icon-yuanxuanze"></i>
                        <i class="iconfont icon-jiameng-1"></i>
                        <span class="company-name">北京翼农飞防植保联盟  </span>
                        <i class="iconfont icon-jiantou"></i>
                    </div>
          
                    <ul class="order-detail">
                        <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                            <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                                <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                    </ul>
            </li>
                <!-- <i class="iconfont icon-fanhui"></i> -->
        </div>
            <div class="order clearfix">
            <div class="left"><span class="iconfont"></span>全选&nbsp;合计： <span class="sum-price">&yen;100050.11</span></div>
            <div class="right" @click="payOrder()">去结算(10)</div>
        </div>
    </div>
</template>
<script>
import OrderHeader from "@/components/order-header/order-header";
export default {
  name: "car-page",
  data() {
    return {
      title: "购物车"
    };
  },
  components: {
    OrderHeader
  },
  methods:{
    payOrder(){
      this.$router.push({
        name:"pay-order-page"
      })
    }
  }
};
</script>

<style lang="scss" scoped>
.cart-page {
  .content {
    .order-item {
      margin-top: 20px;
      // 公司的名字订单
      .order-company {
        padding-left: 28px;
        padding-right: 28px;
        box-sizing: border-box;
        position: relative;
        // background: #ff0;
        height: 78px;
        border: solid 1px rgba(238, 238, 238, 0.9);
        width: 100%;
        line-height: 78px;
        .iconfont {
          font-size: 30px;
        }
        .company-name {
          margin-left: 8px;
          font-size: 30px;
        }
        .icon-yuanxuanze {
          font-size: 36px;
          color: #ff6600;
        }
        .icon-jiameng-1 {
          margin-left: 20px;
        }
        .icon-jiantou {
          margin-left: 10px;
        }
      }
      // 对应的订单的详情列表
      .order-detail {
        padding-left: 0;
        box-sizing: border-box;
        margin: 0 auto;
        .list-detail {
          border-bottom: solid 1px #cccccc;
          padding-top: 20px;
          box-sizing: border-box;

          // background: #ff0;
          padding-left: 28px;
          padding-right: 28px;
          padding-bottom: 30px;
          .select-icon {
            float: left;
            width: 6%;
            .icon-yuanxuanze {
              font-size: 36px;
              color: #ff6600;
            }
          }
          .list-content {
            float: left;
            width: 94%;
            padding-left: 18px;
            box-sizing: border-box;
            .left {
              float: left;
              width: 24%;
              .img {
                width: 144px;
                height: 144px;
              }
            }
            .right {
              float: left;
              width: 74%;
              box-sizing: border-box;
              padding-left: 20px;
              .title {
                margin-top: 0;
                margin-bottom: 0;
                font-size: 30px;
                color: #323232;
                font-weight: 700;
              }
              .desc {
                margin-top: 0;
                margin-bottom: 0;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                overflow: hidden;
                font-size: 26px;

                color: #666666;
              }
              .price {
                margin-top: 26px;
                font-size: 30px;
                .unit {
                  color: #ff6600;
                  font-weight: 700;
                }
                .sum-num {
                  font-size: 30px;
                  color: #333333;
                  float: right;
                }
              }
            }
          }
        }
      }
    }
  }
  .order {
    padding-left: 28px;

    box-sizing: border-box;

    width: 100%;
    height: 100px;
    background-color: #ffffff;
    line-height: 100px;
    // background: #ff0;
    .left {
      float: left;

      .iconfont {
        width: 36px;
        height: 36px;
        float: left;
        margin-top: 34px;
        background-color: #ffffff;
        border: solid 1px #cccccc;
        border-radius: 50%;
        //  padding-left: 6px;
        margin-right: 10px;
      }
      .sum-price {
        color: #333333;
        font-size: 30px;
        font-weight: 500;
      }
    }

    .right {
      float: right;
      width: 210px;
      height: 100px;
      background-color: #ff6c00;

      font-size: 30px;

      color: #ffffff;
      text-align: center;
    }
  }
}
</style>

