<template>
    
    <div class="search-page"></div>
</template>
<script>
    export default {
        name:"search-page",
        data(){
             return{

             }
        }
    }
</script>
<style lang="scss" scoped>
 
 .search-page{

     
 }
</style>
