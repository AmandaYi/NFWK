<template>
    <div class="pay-order-page">   
        
        
        
        
        
        
        
        
        <order-header :title="title"></order-header>
        
        
        <!-- 收货人 -->
            <div class="consignee">
 <p class="item user-info"><span class="name">强美静</span><span class="phone">156****2561</span></p>

<p class="item address-detail" @click="addressPage()"><i class="iconfont icon-zuobiao"></i>河南省郑州市金水区 花园路纬五路<i class="iconfont icon-jiantou"></i></p>
<p class="item time"><i class="iconfont icon-shijian-tianchong"></i> 作业时间:2018-6-5</p>
            </div>
        
        <div class="colour"></div>
        
        
        
          <div class="content">
            <li class="order-item">
                    <div class="order-company">
                        <i class="iconfont icon-yuanxuanze"></i>
                        <i class="iconfont icon-jiameng-1"></i>
                        <span class="company-name">北京翼农飞防植保联盟  </span>
                        <i class="iconfont icon-jiantou"></i>
                    </div>
          
                    <ul class="order-detail">
                        <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                            <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                                <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                    </ul>
            </li>
                <li class="order-item">
                    <div class="order-company">
                        <i class="iconfont icon-yuanxuanze"></i>
                        <i class="iconfont icon-jiameng-1"></i>
                        <span class="company-name">北京翼农飞防植保联盟  </span>
                        <i class="iconfont icon-jiantou"></i>
                    </div>
          
                    <ul class="order-detail">
                        <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                            <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                                <li class="list-detail clearfix">
                            <div class="select-icon">
                               <i class="iconfont icon-yuanxuanze"></i>
                            </div>
                            <div class="list-content clearfix">
                              <div class="left">
                                <img   class="img" alt="">
                              </div>
                              <div class="right">
                                <h2 class="title">低矮大田</h2>
                                <p class="desc">Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste, sint tempore dolor libero quae dolorum facere dicta! Eligendi dignissimos asperiores nostrum in minus earum, possimus ratione, rerum inventore, voluptates eveniet.</p>
                                <div class="price clearfix">
                                  <!-- 单价 -->
                                  <span class="unit">&yen;10.11</span>
                                  <!-- 数量 -->
                                  <span class="sum-num">150亩</span>
                                  </div>
                              </div>
                            </div>
                        </li>
                    </ul>
            </li>
                <div class="item-add-sum">共<span class="item-sum">5</span>件&nbsp;&nbsp;&nbsp;&nbsp;合计： <span class="item-price">&yen;100050.11</span></div>
        </div>
        
        
        
        
        
        
             <div class="order clearfix">
            <div class="left">共<span class="sum-num">5</span>件，合计： <span class="sum-price">&yen;100050.11</span></div>
            <div class="right" @click="modalPay()">提交订单</div>
        </div>  
        
        
        
        
            <div>
                
            </div>
        
        
        </div>
</template>
<script>
import OrderHeader from "@/components/order-header/order-header";
export default {
  name: "pay-order-page",
  data() {
    return {
      title: "确认订单"
    };
  },
  components: {
    OrderHeader
  },
  methods: {
    modalPay() {
      alert(1);
    },
    addressPage(){
this.$router.push({
  name:"address-list-page"
})
    }
  }
};
</script>
<style lang="scss" scoped>
.pay-order-page {
  //             <div class="consignee">
  //  <p class="user-info"><span class="name">强美静</span><span class="phone">156****2561</span></p>

  // <p class="address-detail"><i class="iconfont icon-zuobiao"></i> 河南省郑州市金水区 花园路纬五路 <i class="iconfont icon-jiantou"></i></p>
  // <p class="time"><i class="iconfont icon-shijian-tianchong"></i> 作业时间:2018-6-5</p>
  //             </div>
  .consignee {
    padding-top: 26px;
    padding-bottom: 26px;
    box-sizing: border-box;
    border-top: 2px solid #cccccc;
    .item {
      margin-top: 0;
      margin-bottom: 0;
      font-size: 28px;
      font-size: 28px;
      color: #666666;
      box-sizing: border-box;
      margin-top: 26px;
    }
    .iconfont {
      margin-right: 6px;
      font-size: 28px;
    }
    .user-info {
      font-size: 30px;
      color: #333333;
      font-weight: 700;
      padding-left: 70px;
    }
    .address-detail {
      padding-left: 28px;
    }
    .time {
      padding-left: 28px;
      .iconfont {
        font-size: 24px;
        margin-left: 2px;
        margin-right: 6px;
      }
    }
  }
  .colour {
    width: 100%;
    height: 10px;
    background-image: linear-gradient(
        -90deg,
        #7fccf1 0%,
        #8f82ba 20%,
        #ed9fbe 40%,
        #f09c76 60%,
        #89c797 100%
      ),
      linear-gradient(#00af00, #00af00);
    background-blend-mode: normal, normal;
  }
  .content {
    .order-item {
      margin-top: 20px;
      // 公司的名字订单
      .order-company {
        padding-left: 28px;
        padding-right: 28px;
        box-sizing: border-box;
        position: relative; // background: #ff0;
        height: 78px;
        border: solid 1px rgba(238, 238, 238, 0.9);
        width: 100%;
        line-height: 78px;
        .iconfont {
          font-size: 30px;
        }
        .company-name {
          margin-left: 8px;
          font-size: 30px;
        }
        .icon-yuanxuanze {
          font-size: 36px;
          color: #ff6600;
        }
        .icon-jiameng-1 {
          margin-left: 20px;
        }
        .icon-jiantou {
          margin-left: 10px;
        }
      }
      // 对应的订单的详情列表
      .order-detail {
        padding-left: 0;
        box-sizing: border-box;
        margin: 0 auto;
        .list-detail {
          border-bottom: solid 1px #cccccc;
          padding-top: 20px;
          box-sizing: border-box; // background: #ff0;
          padding-left: 28px;
          padding-right: 28px;
          padding-bottom: 30px;
          .select-icon {
            float: left;
            width: 6%;
            .icon-yuanxuanze {
              font-size: 36px;
              color: #ff6600;
            }
          }
          .list-content {
            float: left;
            width: 94%;
            padding-left: 18px;
            box-sizing: border-box;
            .left {
              float: left;
              width: 24%;
              .img {
                width: 144px;
                height: 144px;
              }
            }
            .right {
              float: left;
              width: 74%;
              box-sizing: border-box;
              padding-left: 20px;
              .title {
                margin-top: 0;
                margin-bottom: 0;
                font-size: 30px;
                color: #323232;
                font-weight: 700;
              }
              .desc {
                margin-top: 0;
                margin-bottom: 0;
                display: -webkit-box;
                -webkit-box-orient: vertical;
                -webkit-line-clamp: 2;
                overflow: hidden;
                font-size: 26px;
                color: #666666;
              }
              .price {
                margin-top: 26px;
                font-size: 30px;
                .unit {
                  color: #ff6600;
                  font-weight: 700;
                }
                .sum-num {
                  font-size: 30px;
                  color: #333333;
                  float: right;
                }
              }
            }
          }
        }
      }
    }
    .item-add-sum {
      font-size: 28px;
      text-align: right;
      height: 88px;
      width: 100%;
      background: #ffffff;
      line-height: 88px;
      box-sizing: border-box;
      padding-right: 28px;
      .item-sum {
      }
      .item-price {
        color: #ff6600;
        font-weight: 700;
      }
    }
  }
  .order {
    padding-left: 28px;
    box-sizing: border-box;
    width: 100%;
    height: 100px;
    background-color: #ffffff;
    line-height: 100px;
    // background: #ff0;
    .left {
      float: left;
      font-size: 28px;
      .sum-num {
        margin-left: 6px;
        margin-right: 6px;
      }
      .sum-price {
        color: #ff6600;
        font-weight: 700;
      }
    }
    .right {
      float: right;
      width: 210px;
      height: 100px;
      background-color: #ff6c00;
      font-size: 30px;
      color: #ffffff;
      text-align: center;
    }
  }
}
</style>
