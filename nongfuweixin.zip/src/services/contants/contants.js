export const SERVICE_URL = "http://192.168.1.13:8080/api/";

















// 图片服务器
export const SERVICE_IMAGES_URL = "http://192.168.1.13:8080/images/";






// 商品图片服务器
export const SERVICE_SHOP_IMAGES_URL = "http://192.168.1.13:8080/pimages/";
















// 登录注册服务器

// export const SERVICE_USER_URL = "http://ggnf.365960.cn/oapi/";
export const SERVICE_USER_URL = "http://192.168.1.13:8088/oapi/";