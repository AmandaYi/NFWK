<template>
    <div>
    个人中心页面工作正常
    </div>
</template>
<script>
    export default {
        name: "personal-page",
        data(){
            return{}
        }
    }
</script>
<style lang="scss" scoped>

</style>
