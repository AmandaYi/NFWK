<template>
    <div>供求页面正常</div>
</template>
<script>
    
    export default {
        name : "supply-demand",
        data(){
            return {


            }
        }
    }
</script>
<script lang="scss" scoped>
    
</script>