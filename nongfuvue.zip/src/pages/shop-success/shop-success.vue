<template>
    
    <div>

        个人中心服务商入住页面最后选择类别页面正常工作
    </div>
</template>
