<template>
    <div>立刻订阅表单页面正常</div>
</template>
<script>
    export default {
        name : "call-subscribe-page"
    }
</script>
