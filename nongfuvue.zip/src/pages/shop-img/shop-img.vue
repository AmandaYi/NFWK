<template>
    
    <div>


    服务商入住页面个人身份证和营业执照提交页面
    </div>
</template>
