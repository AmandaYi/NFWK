<template>
    <div> 公司详情页面正常工作</div>
</template>
<script>
    export default {
        name : "call-company-detail-page"
    }
</script>
