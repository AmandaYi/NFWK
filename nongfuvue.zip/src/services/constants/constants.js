export const SERVICE_URL ="http://192.168.1.13:8080/api/";
export const IMAGES_URL ="http://192.168.1.13:8080/images/";

export const SERVER_URL = 'http://ggnf.365960.cn/oapi/';   
export const SERVER_URL_SHOP = 'http://ggnf.365960.cn/api/';   