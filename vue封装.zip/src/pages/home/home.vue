<template>
    
    <div class="home-page">
        <app-header class="app-header"></app-header>
        <div class="nav clearfix">
            <div class="nav-title">
                <div class="left clearfix"  @click="toggleNavTitle($event)" ref="navTitle">
                     <li class="left-item current"><i class="iconfont icon-nongji"></i>飞防</li>
                     <li class="left-item"><i class="iconfont icon-nongji"></i>农机</li>
                     <li class="left-item"><i class="iconfont icon-nongji"></i>农资</li>
                     <li class="left-item"><i class="iconfont icon-nongji"></i>专家</li>
                </div>
                <div class="right">
                    <i class="right-icon iconfont icon-leibie"></i>
                </div>

            </div>

            <div class="sub-nav clearfix" @click="toggleSubNav($event)" ref="subNav">
                <li class="sub-item" :class="{'sub-item':true,'current':index==0}" :key="index" v-for="(item,index) of subNav">{{item}}</li>
            </div>
        </div>
        <div class="map" id="map" ref="map">
            <i class="iconfont icon-zuobiao"></i>
        </div>
        <div class="marler-detail">
            <marker-page :marker="marker"></marker-page>
        </div>
    </div>
</template>
<script>
// 引入头部
import AppHeader from "components/app-header/app-header";
import MarkerPage from "components/marker-detail/marker-detail";
// 引入vuex,将此页面的map填充进去,PS先实现功能
// import store from '@/store/store';

// import  {mapState} from 'vuex';

import AMap from "AMap";

// 引入图片服务器地址
import { SERVICE_IMAGES_URL } from "../../services/contants/contants";

// 导入api
import ApiService from "../../services/api-service/api-service";
// let map;
// let markers = [];
export default {
  name: "home-page",
  data() {
    return {
      map: "",
      markers: [],
      apiService: new ApiService(),
      nav: [
        {
          id: 0,
          title: "飞防"
        },
        {
          id: 1,
          title: "农机",
          sub: ["农机1", "农机2", "农机3"]
        },
        {
          id: 2,
          title: "农资",
          sub: ["农资1", "农资2", "农资3"]
        },
        {
          id: 3,
          title: "专家",
          sub: ["专家1", "专家2", "专家3"]
        }
      ],
      subNav: ["飞防1", "飞防2", "飞防3"],
      //  marker传入的额数据
      marker: {
        id: 0,
        title: "北京翼农飞防植保联盟",
        rating: 5,
        desc:
          "北京翼农是一家集农业植保高科技器械产 品研究开发、生产、销售、服务于一体的专业化公司",
        telPhone: "15839521352"
      }
    };
  },
  created() {
    this.subNav = this.nav[0].sub;
  },
  mounted() {
    this.init();
    // 得到全部数据
  },
  methods: {
    initMap() {
      let that = this;
      return new Promise(resolve => {
        that.map = new AMap.Map("map", {
          zoom: 15,
          resizeEnable: true,
          center: [113, 34]
        });
        //   输出地图
        resolve(that.map);
      });
    },
    onSuccess(e) {
      let that = this;
      if (e) {
        console.log("geo is save");
        let res = e.position;
        let gysTypeId = gysTypeId || 1;
        let lng = res.lng;
        let lat = res.lat;
        this.apiService.getDistanceGysInfos(gysTypeId, lng, lat).then(r => {
          console.log(r.data);
          let res = r.data;
          for (let i = 0; i < res.length; i++) {
            let newLng = new AMap.LngLat(res[i].longitude, res[i].lat);
            let imgUrl = SERVICE_IMAGES_URL + res[i].gysType.imgUrl;
            console.log(res[i]);

            let marker = new AMap.Marker({
              map: that.map,
              position: newLng,
              icon: imgUrl,
              offset: { x: -8, y: -34 } //相对于基点的位置
            });
            marker.on("click", () => {
              // that.showDeatil(res[i]);
              console.log("我什么都不做");
            });
            that.markers.push(marker); //在地图上添加点
          }
        });
      } else {
        console.error("报错了");
        return false;
      }
    },
    init() {
      let that = this;

      that.initMap(map).then(
        map => {
          map.plugin("AMap.Geolocation", () => {
            let geolocation = new AMap.Geolocation({
              enableHighAccuracy: true, //是否使用高精度定位，默认:true
              timeout: 10000, //超过10秒后停止定位，默认：无穷大
              maximumAge: 0, //定位结果缓存0毫秒，默认：0
              convert: true, //自动偏移坐标，偏移后的坐标为高德坐标，默认：true
              showButton: true, //显示定位按钮，默认：true

              buttonPosition: "RB", //定位按钮停靠位置，默认：'LB'，左下角
              buttonOffset: new AMap.Pixel(16, 220), //定位按钮与设置的停靠位置的偏移量，默认：Pixel(10, 20)
              showMarker: false, //定位成功后在定位到的位置显示点标记，默认：true
              showCircle: true, //定位成功后用圆圈表示定位精度范围，默认：true
              panToLocation: true, //定位成功后将定位到的位置作为地图中心点，默认：true
              zoomToAccuracy: true //定位成功后调整地图视野范围使定位位置及精度范围视野内可见，默认：false
            });
            map.addControl(geolocation);
            geolocation.getCurrentPosition();
            AMap.event.addListener(geolocation, "complete", that.onSuccess); //返回定位信息
            AMap.event.addListener(geolocation, "error", err => {
              console.log(err);
            }); //返回定位出错信息
          });
        },
        e => {
          console.log("BUG! YOU ARE NOT HAVE GPS" + e);
        }
      );
    },
    // 获取点标记
    getTabMarker() {
      // 获取得到的一级类别,
      // 类别分别是
      // 农机 1  飞防 2 农资 3 专家 4 
      // -> 
      let gysTypeId = typeId || 1;
      // 获取得到的经营范围类别,如果不传递经营范围的话,那么最后的值是空字符串
      // 经营范围是
      //  农机 1 有三个范围         深松 9  播种  11  收割 10
      //  农资 3 有四个范围         种子12 化肥13 农药14 农膜15
      let busScopeId = scopedId || 9;
    
      // ->
      let that = this;
      // 当前的可视中心点
      let clientCenter = that.map.getCenter();
      // 当前移动的点标记的中心点
      // 经度,
      let lng = clientCenter.lng;
      // 维度
      let lat = clientCenter.lat;
      // debugger
      // 开始再次查询数据,
      this.apiService.getDistanceGysInfos(gysTypeId, lng, lat).then(res => {
        console.log(res);
      });
    },

    // 点击切换导航栏
    toggleNavTitle(e) {
      let that = this;

      that.getTabMarker();
      // 激活的li
      let current_i = 0;
      // 获取e
      let ev = e || window.event;
      // 获取点击的元素代理
      let target = ev.target || ev.srcElement;
      // 获取子元素,为了for
      let children = this.$refs.navTitle.children;
      console.log(children);

      if (target.nodeName.toLowerCase() == "li") {
        // console.log();
        if (target == undefined || target == null || target == "") {
          return false;
        }
        target.className = "left-item current";

        // 清除全部元素的样式
        console.log(target);

        for (let i = 0; i < children.length; i++) {
          if (children[i] === target) {
            console.log(i);
            current_i = i;
            continue;
          } else {
            children[i].className = "left-item";
          }
        }
        // 把二级菜单的数据数据改变
        that.changeSubNav(current_i);
      } else if (target.nodeName.toLowerCase() == "i") {
        console.log(target);
        if (target == undefined || target == null || target == "") {
          return false;
        }
        // 把获取到的父元素找出来
        let target = target.parentNode.className;

        // console.log();
        target.className = "left-item current";

        // 清除全部元素的样式
        console.log(target);
        for (let i = 0; i < children.length; i++) {
          if (children[i] === target) {
            console.log(i);
            current_i = i;
            continue;
          } else {
            children[i].className = "left-item";
          }
        }
        // 把二级菜单的数据数据改变
        that.changeSubNav(current_i);
      }

      console.log(that.subNav);
      return true;
    },
    // 点击切换二级导航
    toggleSubNav(e) {
      // 获取e
      let ev = e || window.event;
      // 获取点击的元素代理
      let target = ev.target || ev.srcElement;
      // 获取子元素,为了for
      let children = this.$refs.subNav.children;
      if (target.nodeName.toLowerCase() == "li") {
        // console.log();
        target.className = "sub-item current";

        // 清除全部元素的样式
        console.log(target);
        for (let i = 0; i < children.length; i++) {
          if (children[i] === target) {
            console.log(i);
            continue;
          } else {
            children[i].className = "sub-item";
          }
        }
      }
    },
    changeSubNav(current_i) {
      let that = this;
      that.subNav = that.nav[current_i].sub;
      //  同时切换二级导航的样式
      let children = that.$refs.subNav.children;
      // 由于要选中第一个,所以i循环从1开始
      for (let i = 1; i < children.length; i++) {
        children[i].className = "sub-item";
      }
      children[0].className = "sub-item current";
    }
  },
  components: {
    AppHeader,
    MarkerPage
  }
};
</script>
<style lang="scss" scoped>
.home-page {
  height: 100%;
  width: 100%;
  position: relative;
  .app-header {
    position: relative;
    z-index: 900;
  }
  .nav {
    position: relative;
    z-index: 950;
    .nav-title {
      height: 70px;
      width: 100%;
      background-color: #ffffff;
      // line-height: 70px;
      position: relative;
      z-index: 980;
      .left {
        font-size: 28px;
        // display: flex;
        // width: 500px;
        height: 70px;
        // justify-content: space-around;
        // align-items: center;
        color: #666666;
        text-align: center;
        .left-item {
          margin-left: 10px;
          margin-top: 12px;

          // width: 130px;
          padding-left: 18px;
          padding-right: 18px;

          line-height: 48px;
          height: 48px;
          float: left;
          background-color: #ffffff;
          border-radius: 24px;
          color: #666666;

          .iconfont {
            font-size: 28px;
            color: #ffffff;
            margin-right: 10px;
          }
          -webkit-transition: all 0.4s ease-in-out 0s;
          -moz-transition: all 0.4s ease-in-out 0s;
          -o-transition: all 0.4s ease-in-out 0s;
          -ms-transition: all 0.4s ease-in-out 0s;
          transition: all 0.4s ease-in-out 0s;
        }
        //   激活状态
        .current {
          background-color: #00af00;
          color: #ffffff;
        }
      }
      .right {
        position: absolute;
        right: 28px;
        top: 18px;
        z-index: 1000;
        // float: right;
        .right-icon {
          font-size: 30px;
          color: #999999;
        }
      }
    }
    // 二级导航
    .sub-nav {
      box-sizing: border-box;
      float: left;
      margin-left: 28px;
      margin-top: 20px;
      //   width: 370px;
      height: 74px;
      background-color: #ffffff;
      border-radius: 6px;
      padding: 6px;

      .sub-item {
        box-sizing: content-box;
        float: left;
        padding: 14px 34px;
        font-size: 28px;
        color: #666666;
        -webkit-transition: all 0.4s ease-in-out 0s;
        -moz-transition: all 0.4s ease-in-out 0s;
        -o-transition: all 0.4s ease-in-out 0s;
        -ms-transition: all 0.4s ease-in-out 0s;
        transition: all 0.4s ease-in-out 0s;
        border: solid 1px #ffffff;
      }
      .current {
        border: solid 1px rgba(0, 175, 0, 0.9);
      }
    }
  }
  //   地图
  .map {
    position: absolute;
    z-index: 18;
    background: #00ff11;

    height: 100%;
    width: 100%;
    top: 0;
    .iconfont {
      position: absolute;
      top: 50%;
      left: 50%;
      z-index: 20;
      color: #00af00;
      font-size: 44px;
      margin-top: -22px;
      margin-left: -22px;
    }
  }
  // 详情
  .marler-detail {
    position: absolute;
    z-index: 900;
    bottom: 0;
  }
}
</style>

