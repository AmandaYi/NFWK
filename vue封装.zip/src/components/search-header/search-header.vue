<template>
    
    <div class="search-header">


        <p class="form-block"><input type="text">
        
        <i class="iconfont icon-search"></i>
        </p>


    </div>
</template>

<script>
    export default {
        name: "search-header",
        props:{

        }
    }
</script>
<style lang="scss" scoped>

    .saerch-header{

    }

</style>

