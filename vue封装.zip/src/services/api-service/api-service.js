import HttpService from "./../http-service/http-service";


export default class ApiService {
  http = new HttpService();

/**
 * @name 获取指定id的点标记
 * @param {当前的类别 // 农机 1  飞防 2 农资 3 专家 4 } gysTypeId 
 * @param {可视范围内的经度} lng 
 * @param {可视范围内的维度} lat 
 * @param {范围} busScopeId 
 */
  getDistanceGysInfos(gysTypeId, lng, lat, busScopeId = "") {
    let param = {
      gysTypeId,
      lng,
      lat,
      busScopeId
    }
    return this.http.get('gysInfo/getDistanceGysInfos', param);
  }
  /**
   * @name 供应商提交
   * @param formData,注意直接传入一个对象既可,
   * 会自动进行混入formData 
   * {a:1,file:document.getElementById("file")}  
   * 警告,表单数据直接传入
   */
  postGysInfo(formData) {

    return this.http.postFormData('gysInfo/postGysInfo', formData)
  }
  /**
   *@name  用户信息修改
   *@param id
   *@param username
   * 
   */
  putUser(id, username) {
    let param = {
      id,
      username
    }
    return this.http.put('admin-api/user/putUser', param)

  }
  delBusScope(id) {
    let param = {
      id
    };
    return this.http.delete('businessScope/delBusScope', param);
  }

}
