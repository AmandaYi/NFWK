export const SERVICE_URL = "http://192.168.1.13:8080/api/";

















// 图片服务器

export const SERVICE_IMAGES_URL = "http://192.168.1.13:8080/images/";