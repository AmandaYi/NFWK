import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)
// 首页
const HomePage = r => require.ensure([], () => r(require('@/pages/home/home')), 'HomePage');
export default new Router({
  routes: [{
      path: "/",
      name: "home-page",
      redirect:"/home",
    },
    {
      path: "/home",
      name: "home-page",
      component: HomePage,
    }
  ]
})
